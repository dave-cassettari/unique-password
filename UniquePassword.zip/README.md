# Unique Password Generator

A Chrome extension and web application for creating strong site-specific passwords using a single master password.